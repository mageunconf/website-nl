#Newsletter

![MUC Header](http://www.mageunconference.org/mageunconference-2015-berlin.png)


Lieber Magento-Enthusiast,

wir freuen uns, dass wir die erste FireGento Mage Unconference ankündigen können. Die Community lädt weltweit Dich und viele andere Menschen ein, an dieser großartigen und einmaligen Veranstaltung 2015 in Berlin teilzunehmen!

![MUC Logo](http://www.mageunconference.org/MageUC-Logo.png)

## Ein Unconfer…WAS?

Du weißt nicht, was eine Unconference ist? Keine Sorge, wir hatten früher auch keine Ahnung :-) Bei einer Unconference geht es hauptsächlich um Menschen - und mit Menschen meinen wir nicht nur Entwickler. Wir sprechen von Kunden, Händlern, Anbietern, Agenturen und Providern – und ja - natürlich auch Entwicklern. Der Inhalt der Unconference wird ganz alleine von Dir und den anderen Teilnehmern festgelegt. Und wir räumen Diskussionen und Gesprächen jede Menge Zeit ein. Wir bieten Dir eine Veranstaltung, bei der Du Wissen sammeln und teilen kannst. Falls Du also dein Wissen nicht gerne teilst, dann ist eine Unconference nicht das Richtige für Dich!

## Ablauf deiner Unconference

Wir treffen uns am Morgen, um die Themen zu sammeln, über die die Teilnehmer sprechen oder zu denen sie etwas hören möchten. Anschließend basteln wir daraus eine bunt gemischte Themenwiese, über die Du und alle anderen Teilnehmern abstimmen dürfen - sei es, weil Dich ein Thema interessiert oder weil Du selbst zu einem Thema etwas sagen möchtest.

## Wann und wo darf ich hin?

Wir laden Dich ein, Teil der weltweit ersten [Unconference zu Magento](http://www.mageunconference.org/) in Berlin vom 7. bis 8. März 2015 zu sein.

## Als was darf ich teilnehmen?

Verbringe mit uns ein Wochenende, egal was Dich mit Magento verbindet. Wir wünschen uns Gespräche mit Händlern, Agenturen, Entwicklern, Designern, Kunden und Service-Anbietern für Zahlungs- und Versandarten. 

Jeder Teilnehmer ist ein wichtiger Mitspieler. Es ist wichtig, dass wir uns alle einig sind, was wir erreichen wollen:

* Glückliche Menschen
* Steigende Umsätze
* Geniale und leicht bedienbare Shops
* Ausbaufähigen, ordentlichen Programmcode

[Mach mit! Sei Teil der Community!
7.-8. März 2015 in Berlin](https://www.mage-hackathon.de/upcoming/mage-unconference.html)

![MUC Header](http://www.mageunconference.org/get-your-ticket-now.png)
