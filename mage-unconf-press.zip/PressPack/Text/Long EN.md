#Newsletter

![MUC Header](http://www.mageunconference.org/mageunconference-2015-berlin.png)


Dear Magento Enthusiast,

we are proud to announce the first FireGento Mage Unconference. The community invites people across the planet to attend that great happening in Berlin 2015!

![MUC Logo](http://www.mageunconference.org/MageUC-Logo.png)

## An Unconfer…WHAT?

You don't know, what an Unconference is? Don't worry, we did neither :-) An unconference is all about people - and by people we don't talk just about developers. We talk about Customers, Merchants, Providers, Agencies - and yeah - also Developers. The content is whatever the attendees make out of it. And we will have a lot time to discuss, talk and enjoy our shared time. We offer an event to exchange experience and knowledge. So if you don’t like to share,  this is not the right event for you. 

## Outline of the Unconference

We'll meet in the morning, collect topics you would like to talk or hear about. Then we push together a lineup of topics and all attendees vote for their favorite topic - either the one they like to talk about or the one they like to listen to.

## Where to attend

We invite you to be part of the first [Magento related Unconference](http://www.mageunconference.org/) taking place in Berlin, Germany on 7th and 8th of March 2015.

## Who to attend

Join us for one weekend to explore magento from all directions. We'd love to have a good mix of merchants, developers, agencies, designers and solution provider, like payment provider, shipping companies, etc. 

Every part is important and it is even more important, that we all know what we do, what we expect from each other and how to communicate between all of us, to achieve what we all want:

* Happy customers
* Raising revenues
* Easy to use and good looking shops
* and maintainable and extendable code

[Join us now! Be part of the community!
7th and 8th March 2015 in Berlin](https://www.mage-hackathon.de/upcoming/mage-unconference.html)

![MUC Header](http://www.mageunconference.org/get-your-ticket-now.png)
